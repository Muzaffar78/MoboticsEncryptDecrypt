package com.muzaffar.moboticsencryptdecrypt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.muzaffar.moboticsencryptdecrypt.databinding.ActivityMainBinding;

import static com.muzaffar.moboticsencryptdecrypt.ResultActivity.DECRYPT;
import static com.muzaffar.moboticsencryptdecrypt.ResultActivity.ENCRYPT;
import static com.muzaffar.moboticsencryptdecrypt.ResultActivity.TYPE_STRING;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);


        setTitle(getString(R.string.main_activity_title));

        binding.buttonEncrypt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ResultActivity.class);
                intent.putExtra(TYPE_STRING, ENCRYPT);
                startActivity(intent);
            }
        });

        binding.buttonDecrypt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ResultActivity.class);
                intent.putExtra(TYPE_STRING, DECRYPT);
                startActivity(intent);
            }
        });

    }
}
