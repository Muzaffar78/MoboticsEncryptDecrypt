package com.muzaffar.moboticsencryptdecrypt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;

import com.muzaffar.moboticsencryptdecrypt.databinding.ActivityResultBinding;

import java.util.List;

public class ResultActivity extends AppCompatActivity {

    public static final String TYPE_STRING = "type";
    public static final String ENCRYPT = "encrypt";
    public static final String DECRYPT = "decrypt";

    private String previousCharacter = "`";
    private int    previousCharacterCount = 0;

    private ActivityResultBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_result);

        String type = getIntent().getStringExtra(TYPE_STRING);

        if (type.equals(ENCRYPT)) {
            setTitle(getString(R.string.encryption));
            binding.buttonSubmit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    String result = encrypt(binding.editTextResult.getText().toString());
                    binding.textViewResult.setText(result);
                    binding.editTextResult.setText("");
                    previousCharacter = "`";
                    previousCharacterCount = 0;
                }
            });
        } else {
            setTitle(getString(R.string.decryption));
            binding.buttonSubmit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    String result = decrypt(binding.editTextResult.getText().toString().trim());
                    binding.textViewResult.setText(result);
                    binding.editTextResult.setText("");
                    previousCharacter = "`";
                    previousCharacterCount = 0;
                }
            });
        }

        binding.editTextResult.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String s = editable.toString();
                if (s.isEmpty() || s.equals("")) {
                    binding.buttonSubmit.setEnabled(false);
                    binding.buttonSubmit.setBackgroundColor(Color.GRAY);
                } else {
                    binding.buttonSubmit.setEnabled(true);
                    binding.buttonSubmit.setBackgroundColor(getResources().getColor(R.color.submit_button_color));
                }

            }
        });

        binding.editTextResult.setText("");


    }

    private String encrypt(String string) {

        string = string + " ";
        String result = "";
        String[] resultStrings = string.split("");

        for (int i=1; i<resultStrings.length; i++) {

            if (!previousCharacter.equals("`")) {
                String currentCharacter = resultStrings[i];
                if (previousCharacter.equals(currentCharacter)) {
                    previousCharacter = currentCharacter;
                    previousCharacterCount = previousCharacterCount + 1;
                } else {
                    result = result + previousCharacter + "" + previousCharacterCount;
                    previousCharacterCount = 1;
                    previousCharacter = currentCharacter;
                }

            } else {
                previousCharacter = resultStrings[i];
                previousCharacterCount = 1;
            }



        }

        return result;

    }

    private String decrypt(String string) {

        String result = "";
        String[] resultStrings = string.split("");

        for (int i=1; i<resultStrings.length; i = i + 2) {

            try {
                int count = Integer.parseInt(resultStrings[i+1]);
                String character = resultStrings[i];

                for (int j=0; j<count; j++) {
                    result = result + character;
                }
            } catch (Exception e) {
                binding.textViewResult.setText("Error");
            } finally {

            }




        }

        return result;
    }
}
